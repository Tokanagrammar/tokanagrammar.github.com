public class ArithmeticProg {
	public static void main(String[] args) {

	//a few numbers
	int i = 10;
	int j = 20;
	//double x = 10.5;
	//double y = 20.5;

	//adding numbers
	System.out.println("Adding");
	System.out.println(" i + j = " + (i + j));
	//System.out.println(" x + y = " + (x + y));

	//subtracting numbers
	System.out.println("Subtracting");
	System.out.println(" i - j = " + (i - j));
	//System.out.println(" x - y = " + (x - y));

	//multiplying numbers
	System.out.println("Multiplying");
	System.out.println(" i * j = " + (i * j));
	//System.out.println(" x * y = " + (x * y));

	//dividing numbers
	System.out.println("Dividing");
	System.out.println(" i / j = " + (i / j));
	//System.out.println(" x / y = " + (x / y));

	//computing the remainder resulting
	//from dividing numbers
	System.out.println("Modulus");
	System.out.println(" i % j = " + (i % j));
	//System.out.println(" x % y = " + (x % y));

    }
}